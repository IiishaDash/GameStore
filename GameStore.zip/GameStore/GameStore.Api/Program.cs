
using GameStore.Api.Data;
using GameStore.Api.DTOS;
using GameStore.Api.EndPoints;
using Microsoft.AspNetCore.Http.HttpResults;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();


var ConnStr = builder.Configuration.GetConnectionString("GameStore");
builder.Services.AddSqlite<GameStoreDb>(ConnStr);

app.MapEndpoint();

app.Run();
