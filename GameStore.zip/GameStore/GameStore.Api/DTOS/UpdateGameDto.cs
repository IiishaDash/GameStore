namespace GameStore.Api.DTOS;

public record class UpdateGameDto(
   string Name ,
   string Genre,
   decimal Price,
   DateOnly ReleseDate
);
