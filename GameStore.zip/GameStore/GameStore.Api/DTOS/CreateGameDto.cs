namespace GameStore.Api.DTOS;

public record class CreateGameDto(
   string Name,
   string Genre,
   decimal Price,
   DateOnly ReleseDate
);
