using System;
using GameStore.Api.DTOS;
using Microsoft.VisualBasic;

namespace GameStore.Api.EndPoints;

public static class GamesEndpoints

{
    private readonly static List<GameDtos> games = [
    new(
      1,
      "Free Fighter",
      "Sport",
      25.66M,
      new DateOnly(2022,12,23)
   ),
   new(
      2,
      "Free Fighter II",
      "Fighting",
      30.79M,
      new DateOnly(1967,2,4)
   )
 ];

    public static WebApplication MapEndpoint(this WebApplication app)
    {
        app.MapGet("games", () => games);

        app.MapGet("games/{id}", (int id) => games.Find(game => game.Id == id))
           .WithName("GetGames");

        app.MapPost("games/addGame", (CreateGameDto newGame) =>
        {
            GameDtos game = new(
        games.Count + 1,
        newGame.Name,
        newGame.Genre,
        newGame.Price,
        newGame.ReleseDate
    );

            games.Add(game);

            return Results.Ok(game);
        });

        //Update a game with an Id
        app.MapPut("/games/updateGame/{id}", (int id, UpdateGameDto updatedDto) =>
        {
            GameDtos? foundGame = games.Find(game => game.Id == id);
            int index = games.FindIndex(game => game.Id == id);
            if (foundGame == null) return Results.NotFound("Not Found");
            else
            {
                games[index] = new GameDtos(
          id,
          updatedDto.Name,
          updatedDto.Genre,
          updatedDto.Price,
          updatedDto.ReleseDate
        );
            }

            return Results.Ok(games[index]);
        });

        //update partially
        app.MapPatch("/games/update/{id}", (int id, UpdateGameDto updatedGame) =>
        {
            GameDtos? foundGame = games.Find(game => game.Id == id);
            int index = games.FindIndex(game => game.Id == id);
            if (foundGame == null) return Results.NotFound("Not Found");
            else
            {
                GameDtos game = new(
           id,
           updatedGame.Name ?? foundGame.Name,
           updatedGame.Genre ?? foundGame.Genre,
           updatedGame.Price != 0M ? updatedGame.Price : foundGame.Price,
           updatedGame.ReleseDate != null ? updatedGame.ReleseDate : foundGame.ReleseDate
        );

                games[index] = game;
            }

            return Results.Ok(games[index]);
        });

        //delete game of a specified id

        app.MapDelete("/games/delete/{id}", (int id) =>
        {
            int index = games.FindIndex(game => game.Id == id);
            if (index == -1) return Results.NotFound("Not Found");
            else
            {
                games.RemoveAt(index);
            }

            return Results.Redirect("/games");
        });

        app.MapGet("/", () => "Hello World!");


        return app;
    }

}
