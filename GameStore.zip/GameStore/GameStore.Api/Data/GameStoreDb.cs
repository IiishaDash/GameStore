using System;
using GameStore.Api.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace GameStore.Api.Data;

public class GameStoreDb : DbContext
{
    public GameStoreDb(DbContextOptions<GameStoreDb> options) : base(options) {  }

    public DbSet<Genre> Genres;
    public DbSet<Game> Games;
}
